package com.company;

public class Employee {
    String name="The name is amruta";
    int age=18;
    String city="kerala";
    public void display(){
        System.out.println(name);
        System.out.println(age);
        System.out.println(city);
    }
}
